<?php

define("IP","192.168.1.105");
//echo IP;


//-------------- Local Variable
//function play()
//{
//	$Name="Ali";
//	echo $Name;
//}
//play();



//-------------- Global Variable
//$Name="";
//function play()
//{
//	global $Name;
//	$Name="Ali";
//	
//}
//play();
//echo $Name;
//--------------


//-------------- Static Variable

//function play()
//{
//	static $a=1;
//	$a++;
//	echo $a."<br>";
//}
//play();
//play();
//play();
//play();
//play();
//play();



// Environment variables


//echo $_SERVER["HTTP_USER_AGENT"];

//phpinfo();


//$b=true;
//$b=!$b;
//$b=!$b;
//$b=!$b;
//$b=!!!!!$b;
//
//if($b)
//{
//	echo "this is true";
//	
//}
//else
//{
//	echo "this is false";
//}





$marks=30;
$result=$marks>=40?"Pass":"Fail";
echo $result;

	
	
	
	
	
	
	
?>






















